#ifndef JUST_NEED_TYPES
#ifndef INClUDED_FILE_CDB_PROTOS
#define INClUDED_FILE_CDB_PROTOS

#include "storage_file.h"

namespace pvpgn
{

namespace bnetd
{

extern t_file_engine file_cdb;

}

}

#endif /* INClUDED_FILE_CDB_PROTOS */
#endif /* JUST_NEED_TYPES */
