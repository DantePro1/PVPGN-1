#ifndef JUST_NEED_TYPES
#ifndef INClUDED_FILE_PLAIN_PROTOS
#define INClUDED_FILE_PLAIN_PROTOS

#include "storage_file.h"

namespace pvpgn
{

namespace bnetd
{

extern t_file_engine file_plain;

}

}

#endif /* INClUDED_FILE_PLAIN_PROTOS */
#endif /* JUST_NEED_TYPES */
